<h1> login successful </h1>
    <form action="pdf.php" method="post">
		<!-- <h2>Login</h2> --> 
		<hr>
        <div class="form-group">
        	<input type="text" class="form-control" name="pdf_link" placeholder="Pdf" required="required">
        </div>
        <div class="form-group">    
            <button type="submit" class="btn btn-primary btn-lg">Submit</button>
        </div>
    </form>