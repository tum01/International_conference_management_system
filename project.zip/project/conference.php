<form action="newconference.php" method="post">
		<!-- <h2>Login</h2> -->
		<p>Please enter Conference details!</p>
		<hr>
        <div class="form-group">
			<div class="row">
				<div class="col-xs-6"><input type="text" class="form-control" name="topic" placeholder="Topic" required="required"></div>
				<div class="col-xs-6"><input type="date" class="form-control" name="deadline" placeholder="Deadline" required="required"></div>
			</div>        	
        </div>
        <div class="form-group">    
            <button type="submit" class="btn btn-primary btn-lg">Submit</button>
        </div>  
    </form>

